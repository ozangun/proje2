-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 09 May 2023, 15:35:34
-- Sunucu sürümü: 10.4.27-MariaDB
-- PHP Sürümü: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ozan_gun_221109004`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `countries_list`
--

CREATE TABLE `countries_list` (
  `country_id` tinyint(3) UNSIGNED NOT NULL,
  `country` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `countries_list`
--

INSERT INTO `countries_list` (`country_id`, `country`) VALUES
(1, 'Abhazya'),
(2, 'Afganistan'),
(3, 'Almanya'),
(4, 'Amerika Birleşik Devletleri'),
(5, 'Andorra'),
(6, 'Angola'),
(7, 'Antigua ve Barbuda'),
(8, 'Arjantin'),
(9, 'Arnavutluk'),
(10, 'Avustralya'),
(11, 'Avusturya'),
(12, 'Azerbaycan'),
(13, 'Bahamalar'),
(14, 'Bahreyn'),
(15, 'Bangladeş'),
(16, 'Barbados'),
(17, 'Batı Sahra'),
(18, 'Belarus'),
(19, 'Belçika'),
(20, 'Belize'),
(21, 'Benin'),
(22, 'Bhutan'),
(23, 'Birleşik Arap Emirlikleri'),
(24, 'Bolivya'),
(25, 'Bosna Hersek'),
(26, 'Botsvana'),
(27, 'Brezilya'),
(28, 'Brunei'),
(29, 'Bulgaristan'),
(30, 'Burkina Faso'),
(31, 'Burundi'),
(32, 'Cezayir'),
(33, 'Cibuti Cumhuriyeti'),
(34, 'Çad'),
(35, 'Çek Cumhuriyeti'),
(36, 'Çin Halk Cumhuriyeti'),
(37, 'Dağlık Karabağ Cumhuriyeti'),
(38, 'Danimarka'),
(39, 'Doğu Timor'),
(40, 'Dominik Cumhuriyeti'),
(41, 'Dominika'),
(42, 'Ekvador'),
(43, 'Ekvator Ginesi'),
(44, 'El Salvador'),
(45, 'Endonezya'),
(46, 'Eritre'),
(47, 'Ermenistan'),
(48, 'Estonya'),
(49, 'Etiyopya'),
(50, 'Fas'),
(51, 'Fiji'),
(52, 'Fildişi Sahilleri'),
(53, 'Filipinler'),
(54, 'Filistin'),
(55, 'Finlandiya'),
(56, 'Fransa'),
(57, 'Gabon'),
(58, 'Gambiya'),
(59, 'Gana'),
(60, 'Gine Bissau'),
(61, 'Gine'),
(62, 'Grenada'),
(63, 'Guyana'),
(64, 'Guatemala'),
(65, 'Güney Afrika Cumhuriyeti'),
(66, 'Güney Kore'),
(67, 'Güney Osetya'),
(68, 'Gürcistan'),
(69, 'Haiti'),
(70, 'Hırvatistan'),
(71, 'Hindistan'),
(72, 'Hollanda'),
(73, 'Honduras'),
(74, 'Irak'),
(75, 'İngiltere'),
(76, 'İran'),
(77, 'İrlanda'),
(78, 'İspanya'),
(79, 'İsrail'),
(80, 'İsveç'),
(81, 'İsviçre'),
(82, 'İtalya'),
(83, 'İzlanda'),
(84, 'Jamaika'),
(85, 'Japonya'),
(86, 'Kamboçya'),
(87, 'Kamerun'),
(88, 'Kanada'),
(89, 'Karadağ'),
(90, 'Katar'),
(91, 'Kazakistan'),
(92, 'Kenya'),
(93, 'Kırgızistan'),
(94, 'Kıbrıs Cumhuriyeti'),
(95, 'Kiribati'),
(96, 'Kolombiya'),
(97, 'Komorlar'),
(98, 'Kongo'),
(99, 'Kongo Demokratik Cumhuriyeti'),
(100, 'Kosova'),
(101, 'Kosta Rika'),
(102, 'Kuveyt'),
(103, 'Kuzey Kıbrıs Türk Cumhuriyeti'),
(104, 'Kuzey Kore'),
(105, 'Küba'),
(106, 'Lakota Cumhuriyeti'),
(107, 'Laos'),
(108, 'Lesotho'),
(109, 'Letonya'),
(110, 'Liberya'),
(111, 'Libya'),
(112, 'Liechtenstein'),
(113, 'Litvanya'),
(114, 'Lübnan'),
(115, 'Lüksemburg'),
(116, 'Macaristan'),
(117, 'Madagaskar'),
(118, 'Makedonya Cumhuriyeti'),
(119, 'Malavi'),
(120, 'Maldivler'),
(121, 'Malezya'),
(122, 'Mali'),
(123, 'Malta'),
(124, 'Marshall Adaları'),
(125, 'Meksika'),
(126, 'Mısır'),
(127, 'Mikronezya'),
(128, 'Moğolistan'),
(129, 'Moldova'),
(130, 'Monako'),
(131, 'Moritanya'),
(132, 'Moritus'),
(133, 'Mozambik'),
(134, 'Myanmar'),
(135, 'Namibya'),
(136, 'Nauru'),
(137, 'Nepal'),
(138, 'Nikaragua'),
(139, 'Nijer'),
(140, 'Nijerya'),
(141, 'Norveç'),
(142, 'Orta Afrika Cumhuriyeti'),
(143, 'Özbekistan'),
(144, 'Pakistan'),
(145, 'Palau'),
(146, 'Panama'),
(147, 'Papua Yeni Gine'),
(148, 'Paraguay'),
(149, 'Peru'),
(150, 'Polonya'),
(151, 'Portekiz'),
(152, 'Romanya'),
(153, 'Ruanda'),
(154, 'Rusya Federasyonu'),
(155, 'Saint Kitts ve Nevis'),
(156, 'Saint Lucia'),
(157, 'Saint Vincent ve Grenadinler'),
(158, 'Samoa'),
(159, 'San Marino'),
(160, 'Sao Tome ve Principe'),
(161, 'Sealand'),
(162, 'Senegal'),
(163, 'Seyşeller'),
(164, 'Sırbistan'),
(165, 'Sierra Leone'),
(166, 'Singapur'),
(167, 'Slovakya'),
(168, 'Slovenya'),
(169, 'Solomon Adaları'),
(170, 'Somali'),
(171, 'Somaliland'),
(172, 'Sri Lanka'),
(173, 'Sudan'),
(174, 'Surinam'),
(175, 'Suudi Arabistan'),
(176, 'Suriye'),
(177, 'Svaziland'),
(178, 'Şili'),
(179, 'Tacikistan'),
(180, 'Tamil Eelam'),
(181, 'Tanzanya'),
(182, 'Tayland'),
(183, 'Tayvan'),
(184, 'Togo'),
(185, 'Tonga'),
(186, 'Transdinyester'),
(187, 'Trinidad ve Tobago'),
(188, 'Tunus'),
(189, 'Tuvalu'),
(190, 'Türkiye'),
(191, 'Türkmenistan'),
(192, 'Uganda'),
(193, 'Ukrayna'),
(194, 'Umman'),
(195, 'Uruguay'),
(196, 'Ürdün'),
(197, 'Vanuatu'),
(198, 'Vatikan'),
(199, 'Venezuela'),
(200, 'Vietnam'),
(201, 'Yemen'),
(202, 'Yeni Zelanda'),
(203, 'Yeşil Burun'),
(204, 'Yunanistan'),
(205, 'Zambiya'),
(206, 'Zimbabve');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kayitbilgileri`
--

CREATE TABLE `kayitbilgileri` (
  `name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `kayitbilgileri`
--

INSERT INTO `kayitbilgileri` (`name`, `gender`, `country`, `file`, `tel`, `email`) VALUES
('Deneme', 'Erkek', 'Belçika', 'Vize Ödevi                               20 (1).pdf', '05555555555', 'Deneme@hotmail.com');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `countries_list`
--
ALTER TABLE `countries_list`
  ADD PRIMARY KEY (`country_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `countries_list`
--
ALTER TABLE `countries_list`
  MODIFY `country_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=207;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
