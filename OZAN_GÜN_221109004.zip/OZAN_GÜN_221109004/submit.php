<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ozan_gun_221109004";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


  $name = $_POST["name"];
  $gender = $_POST["gender"];
  $country = $_POST["country"];
  $file = $_FILES["file"]["name"];
  $tel = $_POST["tel"];
  $email = $_POST["email"];

$sql = "INSERT INTO kayitbilgileri (name, gender, country, file, tel, email) 
      VALUES ('$name', '$gender', '$country', '$file', '$tel', '$email')";
if ($conn->query($sql) === TRUE) {
echo "Kayıt başarıyla eklendi";
echo " 
<head>

<meta http-equiv='refresh' content='2; url=ozan_gun_221109004.php'> 

</head>";


} else {
echo "Hata: " . $sql . "<br>" . $conn->error;
}



$conn->close();
?>