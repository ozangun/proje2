<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
	<title>Kayıt Formu</title>
	<style>
		body {
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
}

h1 {
  text-align: center;
  color: #333333;
}

form {
  width: 300px;
  margin: 0 auto;
  background-color: #ffffff;
  border: 1px solid #cccccc;
  padding: 20px;
  border-radius: 5px;
  margin-top:5%;
}

label {
  margin-bottom: 5px;
  color: #333333;
  float:left;
}
#checkbox{
    float:left;
}

input[type="text"],
input[type="password"],
input[type="email"],
input[type="tel"],
select,
input[type="file"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #cccccc;
  border-radius: 3px;
  margin-bottom: 15px;
  box-sizing: border-box;
}

input[type="submit"] {
  background-color: #333333;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  border-radius: 3px;
  cursor: pointer;
  width: 100%;
  margin-top:10px;
}

input[type="submit"]:hover {
  background-color: #555555;
}

	</style>
</head>
<body>




	<form method="POST" enctype="multipart/form-data" action="submit.php">
		<h1>KAYIT FORMU</h1>
		<input type="text" id="name" name="name" required placeholder="Ad Soyad" pattern="[A-Za-zğüşıöçĞÜŞİÖÇ\s]+">
		
		
		<select id="gender" name="gender" required>
			<option value="">Cinsiyet Seçiniz</option>
			<option value="Erkek">Erkek</option>
			<option value="Kadın">Kadın</option>
		</select>

		
		<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ozan_gun_221109004";

$conn = new mysqli($servername, $username, $password, $dbname);


$sql = "SELECT country FROM countries_list";
$result = $conn->query($sql);



echo "<select id='country' name='country' required>";
echo "<option value=''>" .'Seçiniz'. "</option>";
while($row = $result->fetch_assoc()) {
    echo "<option value='" . $row['country'] . "'>" . $row['country'] . "</option>";
}
echo "</select>";


$conn->close();
?>

        
		<input type="file" id="file" name="file" required >
		
		
		<input type="tel" id="tel" name="tel" required placeholder="Tel Numarası Ör:0555-555-55-55 Boşluksuz" pattern="[0]\d{3}\d{3}\d{2}\d{2}">
		
		
		<input type="email" id="email" name="email" required placeholder="E-posta adresi" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$">

        
		<input type="checkbox" id="checkbox" name="checkbox" required>
        <label for="checkbox">Bilgileri onaylıyorum.</label>

		

		<input type="submit" value="KAYDET">
	</form>
 
</body>
</html>
